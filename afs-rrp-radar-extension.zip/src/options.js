// AFS RRP Radar — options: enable, store->storefront map, currency.
const $ = (id) => document.getElementById(id);

const DEFAULTS = {
  'gymandfitness-au': 'https://www.gymandfitness.com.au',
  'revel-saunas': 'https://revelsaunas.com.au'
};

function addRow(store, domain) {
  const wrap = document.createElement('div');
  wrap.className = 'maprow';
  wrap.innerHTML =
    '<input type="text" class="store" placeholder="store-handle" value="' + (store || '') + '">' +
    '<input type="text" class="domain" placeholder="https://brand.com.au" value="' + (domain || '') + '">' +
    '<button class="small remove" title="Remove">&times;</button>';
  wrap.querySelector('.remove').addEventListener('click', () => wrap.remove());
  $('map').appendChild(wrap);
}

function load() {
  chrome.storage.sync.get(['enabled', 'storefronts', 'currency'], (s) => {
    $('enabled').checked = s.enabled !== false;
    $('currency').value = s.currency || 'AUD';
    const map = Object.assign({}, DEFAULTS, s.storefronts || {});
    $('map').innerHTML = '';
    Object.keys(map).forEach(store => addRow(store, map[store]));
    if (!Object.keys(map).length) addRow('', '');
  });
}

$('addRow').addEventListener('click', () => addRow('', ''));

$('save').addEventListener('click', () => {
  const storefronts = {};
  document.querySelectorAll('#map .maprow').forEach(r => {
    const store = r.querySelector('.store').value.trim();
    let domain = r.querySelector('.domain').value.trim().replace(/\/+$/, '');
    if (store && domain) {
      if (!/^https?:\/\//.test(domain)) domain = 'https://' + domain;
      storefronts[store] = domain;
    }
  });
  const currency = ($('currency').value.trim() || 'AUD').toUpperCase();
  chrome.storage.sync.set({ enabled: $('enabled').checked, storefronts, currency }, () => {
    const el = $('saved'); el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 1600);
  });
});

load();
