import { getRecording, clearRecording } from './lib/recordingstore.js';

const player = document.getElementById('player');
const download = document.getElementById('download');
const discard = document.getElementById('discard');

const rec = await getRecording();
const { lastError } = await chrome.storage.local.get('lastError');
let url = null;

if (rec && rec.blob) {
  url = URL.createObjectURL(rec.blob);
  player.src = url;
  download.href = url;
  download.setAttribute('download', rec.filename);
  await chrome.storage.local.remove('lastError');
} else {
  // No recording: hide the player/actions/share and show a message.
  player.style.display = 'none';
  document.querySelector('.actions').style.display = 'none';
  document.querySelector('.share').style.display = 'none';
  const h1 = document.querySelector('h1');
  if (lastError) {
    h1.textContent = 'Recording failed';
    const p = document.createElement('p');
    p.style.cssText = 'color:#b91c1c;font-size:14px;background:#fef2f2;border:1px solid #fecaca;padding:16px;border-radius:12px;white-space:pre-wrap;';
    p.textContent = lastError;
    h1.insertAdjacentElement('afterend', p);
  } else {
    h1.textContent = 'No recording found.';
  }
}

discard.addEventListener('click', async () => {
  if (url) URL.revokeObjectURL(url);
  await clearRecording();
  window.close();
});
