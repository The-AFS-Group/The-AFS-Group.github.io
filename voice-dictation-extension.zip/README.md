# VoiceType — voice dictation for Chrome / ChromeOS

Press **Alt+Q** in any text field, speak, and clean formatted text drops in.
Transcription uses Chrome's built-in (free) speech engine; Gemini only tidies
the result, so running cost is fractions of a cent.

---

## Install on your Chromebook

1. **Unzip** the file you were emailed: open **Files** → right-click
   `voice-dictation-extension.zip` → **Extract**. You'll get a folder called
   `voice-dictation-extension`.
2. Open Chrome and go to **`chrome://extensions`**.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** (top-left) and select the **`voice-dictation-extension`
   folder** (the one with `manifest.json` inside it).
5. The "VoiceType" tile appears. Pin it if you like (puzzle-piece icon → pin).

## Set your key (one time)

1. On the VoiceType tile click **Details → Extension options**
   (or right-click the toolbar icon → **Options**).
2. Paste your **Gemini API key** and click **Save**.
   - Don't have one? Go to `aistudio.google.com` → **Get API key** → create one
     (free). It looks like `AIza…`.

## Use it

1. Click into any text field (Gmail, a form, a comment box…).
2. Press **Alt+Q**. A "🎤 Listening…" pill appears bottom-right.
3. Speak. Press **Alt+Q** again to stop (or just pause).
4. Cleaned text is inserted at your cursor — and also copied to the clipboard as
   a backup (press **Ctrl+V** if a stubborn editor doesn't take it directly).

### Good to know

- **First time on a new website** Chrome asks to allow the microphone. Click
  **Allow** once and it's remembered for that site.
- **Reload any tabs** that were already open before you installed the extension.
- Won't work on Chrome's own pages (`chrome://…`, the new-tab page, web store) —
  that's a Chrome rule, not a bug.
- Needs an internet connection (the free speech engine is cloud-based).
- Change the shortcut any time at `chrome://extensions/shortcuts`.

## Privacy / cost

- Your microphone audio goes to Google's speech service (same as ChromeOS
  dictation) — free.
- Only the resulting **text** is sent to Gemini for formatting — pennies.
- Your API key is stored locally on the device and is never written into the
  extension's code files.
