// VoiceType — content script (runs inside every normal web page)
// Listens for the toggle message, captures speech with the browser's free
// engine, asks the background worker to clean it up via Gemini, then drops the
// result into whatever field you were focused on.

(() => {
  let recognition = null;
  let listening = false;
  let targetEl = null;
  let finalTranscript = "";

  // ---- helpers --------------------------------------------------------------

  function editableTarget(el) {
    if (!el) return null;
    const tag = el.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return el;
    if (el.isContentEditable) return el;
    return null;
  }

  function copyToClipboard(text) {
    // execCommand('copy') works without a fresh user gesture, unlike the async
    // Clipboard API. Used as a universal safety net (e.g. Google Docs, where
    // direct insertion can fail).
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      return true;
    } catch (e) {
      return false;
    }
  }

  function insertText(el, text) {
    if (!el) return false;
    el.focus();
    if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
      const start = el.selectionStart ?? el.value.length;
      const end = el.selectionEnd ?? el.value.length;
      el.value = el.value.slice(0, start) + text + el.value.slice(end);
      const pos = start + text.length;
      el.selectionStart = el.selectionEnd = pos;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
    // contenteditable (Gmail, most rich editors)
    const ok = document.execCommand("insertText", false, text);
    return ok;
  }

  // ---- on-screen indicator --------------------------------------------------

  let pill = null;
  function showPill(text) {
    if (!pill) {
      pill = document.createElement("div");
      pill.style.cssText =
        "position:fixed;bottom:20px;right:20px;z-index:2147483647;" +
        "background:#1a1a1a;color:#fff;font:13px/1.4 system-ui,sans-serif;" +
        "padding:8px 14px;border-radius:20px;box-shadow:0 2px 10px rgba(0,0,0,.3);" +
        "pointer-events:none;transition:opacity .2s;";
      document.body.appendChild(pill);
    }
    pill.textContent = text;
    pill.style.opacity = "1";
  }
  function hidePill(delay = 0) {
    if (!pill) return;
    setTimeout(() => {
      if (pill) pill.style.opacity = "0";
    }, delay);
  }

  // ---- core -----------------------------------------------------------------

  function toggle() {
    if (listening) {
      stop();
    } else {
      start();
    }
  }

  function start() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      showPill("🎤 Speech recognition not available here");
      hidePill(2500);
      return;
    }
    targetEl = editableTarget(document.activeElement);
    if (!targetEl) {
      showPill("🎤 Click into a text field first, then Alt+Q");
      hidePill(2800);
      return;
    }

    finalTranscript = "";
    recognition = new SR();
    recognition.lang = "en-AU";
    recognition.interimResults = true;
    recognition.continuous = true;

    recognition.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalTranscript += t;
        else interim += t;
      }
      showPill("🎤 " + (finalTranscript + interim).trim().slice(-60) || "🎤 Listening…");
    };

    recognition.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        showPill("🎤 Microphone blocked — allow mic for this site, then Alt+Q");
        hidePill(4000);
      } else if (e.error === "no-speech") {
        showPill("🎤 Didn't catch anything");
        hidePill(2000);
      }
    };

    recognition.onend = async () => {
      listening = false;
      const raw = finalTranscript.trim();
      recognition = null;
      if (!raw) {
        hidePill(1200);
        return;
      }
      showPill("✍️ Cleaning up…");
      let text = raw;
      try {
        const resp = await chrome.runtime.sendMessage({
          type: "format",
          text: raw,
          host: location.hostname,
        });
        if (resp && resp.text) text = resp.text;
      } catch (e) {
        // background unavailable — use raw
      }
      const inserted = insertText(targetEl, text + " ");
      if (!inserted) {
        copyToClipboard(text); // safety net only when direct insert fails
        try { targetEl.focus(); } catch (e) {}
      }
      showPill(inserted ? "✅ Inserted" : "📋 Copied — press Ctrl+V to paste");
      hidePill(inserted ? 1200 : 3500);
    };

    recognition.start();
    listening = true;
    showPill("🎤 Listening… press Alt+Q to stop");
  }

  function stop() {
    if (recognition) {
      try {
        recognition.stop();
      } catch (e) {}
    }
    listening = false;
  }

  // ---- messaging ------------------------------------------------------------

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "toggle-dictation") toggle();
  });
})();
