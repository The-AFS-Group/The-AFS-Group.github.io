// VoiceType — settings page logic

// Default formatting style (Wispr Flow-like). Keep in sync with DEFAULT_PROMPT
// in background.js.
const DEFAULT_PROMPT =
  "You are a dictation formatter, like Wispr Flow. Turn raw dictated speech " +
  "into clean, well-formatted, ready-to-send text.\n" +
  "- Fix capitalisation, punctuation, grammar and spelling (Australian English).\n" +
  "- Remove filler words (um, uh, er, like, you know) and false starts.\n" +
  "- Format intelligently for the content: short paragraphs for prose; bullet " +
  "points (a hyphen + space) when the speaker is clearly listing items; " +
  "numbered lists for ordered steps.\n" +
  "- Obey spoken formatting cues such as 'new line', 'new paragraph', 'next " +
  "point', 'bullet point', then remove the cue words themselves.\n" +
  "- Preserve the speaker's tone and meaning. Never add new information.";

// Example per-site rules shown the first time, so the pattern is obvious.
const DEFAULT_RULES = [
  {
    match: "whatsapp",
    instruction:
      "Casual, conversational tone like a text message. No bullet points or " +
      "headings. Keep it short and natural. Light punctuation is fine.",
  },
  {
    match: "mail.google",
    instruction:
      "Professional email tone. Use paragraphs, not bullet points unless " +
      "clearly listing. Keep courtesies like please and thanks.",
  },
];

const keyInput = document.getElementById("key");
const modelInput = document.getElementById("model");
const promptInput = document.getElementById("prompt");
const rulesEl = document.getElementById("rules");
const status = document.getElementById("status");

// ---- per-site rule rows -----------------------------------------------------

function addRuleRow(match = "", instruction = "") {
  const row = document.createElement("div");
  row.className = "rule";
  row.innerHTML = `
    <div class="top">
      <strong style="font-size:13px;color:#555">When the website contains…</strong>
      <button class="danger remove" type="button">Remove</button>
    </div>
    <div class="row" style="margin-top:6px">
      <input class="match" type="text" placeholder="whatsapp" />
    </div>
    <textarea class="instruction" style="min-height:64px;margin-top:8px"
      placeholder="…apply these extra formatting instructions"></textarea>
  `;
  row.querySelector(".match").value = match;
  row.querySelector(".instruction").value = instruction;
  row.querySelector(".remove").addEventListener("click", () => row.remove());
  rulesEl.appendChild(row);
}

function collectRules() {
  return [...rulesEl.querySelectorAll(".rule")]
    .map((r) => ({
      match: r.querySelector(".match").value.trim(),
      instruction: r.querySelector(".instruction").value.trim(),
    }))
    .filter((r) => r.match && r.instruction);
}

// ---- load -------------------------------------------------------------------

chrome.storage.local.get(
  ["geminiKey", "geminiModel", "formatPrompt", "siteRules"],
  (s) => {
    if (s.geminiKey) keyInput.value = s.geminiKey;
    if (s.geminiModel) modelInput.value = s.geminiModel;
    promptInput.value = s.formatPrompt || DEFAULT_PROMPT;
    const rules = Array.isArray(s.siteRules) ? s.siteRules : DEFAULT_RULES;
    if (rules.length === 0) addRuleRow();
    else rules.forEach((r) => addRuleRow(r.match, r.instruction));
  }
);

// ---- actions ----------------------------------------------------------------

document.getElementById("addRule").addEventListener("click", () => addRuleRow());

document.getElementById("reset").addEventListener("click", () => {
  promptInput.value = DEFAULT_PROMPT;
});

document.getElementById("save").addEventListener("click", () => {
  chrome.storage.local.set(
    {
      geminiKey: keyInput.value.trim(),
      geminiModel: modelInput.value,
      formatPrompt: promptInput.value.trim() || DEFAULT_PROMPT,
      siteRules: collectRules(),
    },
    () => {
      status.textContent = "Saved ✓";
      setTimeout(() => (status.textContent = ""), 2000);
    }
  );
});
